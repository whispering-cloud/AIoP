# 油墨

![From Chameleon, in case you were wondering.](oredict:oc:chamelium)

油墨是用于3D打印的有序合成物品. 它本身没什么特色，只能拿来盖盖单色的墙.

你可以把它做成 [油墨块](../block/chameliumBlock.md).

正如tip所说, 吃下去的后果不可描述，小心使用，或者最好就别吃他
