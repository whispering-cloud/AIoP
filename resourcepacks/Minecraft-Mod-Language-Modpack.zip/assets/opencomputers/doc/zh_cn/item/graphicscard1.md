# 显卡（GTX 690！）

![Fancy images.](oredict:oc:graphicsCard1)

对大多数计算机都非常重要[computers](../general/computer.md)，显卡允许 [计算机](../general/computer.md)在连接的[屏幕](../block/screen1.md)显示字符. 有数个档次，如同屏幕那样支持多个分辨率
