# Robot
![His name was Tobor.](block:OpenComputers:robot)
和电脑不同 ,机器人可以如同实体那样在地图上移动，但机器人无法和外界组件交互，但！如果要和电脑或者其他机器人通讯,请安装 [无线网卡](../item/wlanCard1.md),或者是通过[红石卡](../item/redstoneCard1.md)收发红石信号建立底层的协议

把[任意机箱](case1.md)放进[组装机](assembler.md)就可以制作机器人. 
高级的机箱由于有更高级的[CPU](../item/cpu1.md)，可以制造更复杂的机器人. 机器人的复杂度 (显示在 [组装机](assembler.md)GUI) 由槽内安装的组件和升级决定; 
高级组件将会大大增加复杂度. 太复杂的情况下, 组装机会选择罢工
多种升级可以扩展机器人的能力， 包括 [物品栏升级](../item/inventoryUpgrade.md) ， [物品栏控制升级](../item/inventoryControllerUpgrade.md) , [储罐升级](../item/tankUpgrade.md), 
[导航升级](../item/navigationUpgrade.md)等等. [升级](../item/upgradeContainer1.md) 和 [卡](../item/cardContainer1.md) 可以被热插拔哦
[软驱](diskDrive.md) 可以被作为机器人的组件，允许插入[软盘](../item/floppy.md)来安装openOS，当然你可以在组装的时候就丢一块安好系统的硬盘进去。
    